'use strict';

/**
 * lead-form-submission router.
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::lead-form-submission.lead-form-submission');
