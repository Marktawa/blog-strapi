'use strict';

/**
 *  lead-form-submission controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::lead-form-submission.lead-form-submission');
