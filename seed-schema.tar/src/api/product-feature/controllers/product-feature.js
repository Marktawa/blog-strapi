'use strict';

/**
 * product-feature controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::product-feature.product-feature');
