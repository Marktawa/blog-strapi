'use strict';

/**
 * product-feature service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::product-feature.product-feature');
