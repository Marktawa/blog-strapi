'use strict';

/**
 * product-feature router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::product-feature.product-feature');
