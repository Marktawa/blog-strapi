'use strict';

/**
 * author service.
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::author.author');
